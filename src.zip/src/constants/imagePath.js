export default {
    icCurLoc: require('../assets/images/Oval.png'),
    icGreenMarker: require("../assets/images/greenMarker.png"),
    greenIndicator: require("../assets/images/greenIndicator.png"),
    icBike: require("../assets/images/bike.png"),
}