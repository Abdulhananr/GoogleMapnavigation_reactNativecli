export const GOOGLE_MAP_KEY = "AIzaSyAIK7Latdow_7V9Arlcy5RtG9gj0hMn0qw"
